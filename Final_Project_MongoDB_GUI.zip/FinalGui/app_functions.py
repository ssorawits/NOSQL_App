
from main import *

class Functions(MainWindow):
    pass
